package main

import (
	"context"
	"fmt"

	"github.com/aws/aws-lambda-go/events"
	"github.com/aws/aws-lambda-go/lambda"
)

func handler(ctx context.Context, s3Event events.S3Event) {
	eventSource := s3Event.Records[0].EventSource
	eventTime := s3Event.Records[0].EventTime
	s3 := s3Event.Records[0].S3
	bucket := s3.Bucket.Name
	obj := s3.Object.Key
	fmt.Printf("[%s - %s] Bucket = %s, Key = %s \n", eventSource, eventTime, bucket, obj)
}

func main() {
	lambda.Start(handler)
}
